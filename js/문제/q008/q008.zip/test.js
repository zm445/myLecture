var x = 3;

if (x == 1) {
    document.write("1");
} else if (x == 2) {
    document.write("2");
} else if (x == 3) {
    document.write("3");
} else if (x == 4) {
    document.write("4");
} else if (x == 5) {
    document.write("5");
} else {
    document.write("1 2 둘다 아님");
}